#!/usr/bin/env python3
"""Native launcher: opens the bundled index.html in a WebKitGTK window."""
import os
import sys
import gi

gi.require_version("Gtk", "4.0")
gi.require_version("WebKit", "6.0")
from gi.repository import Gtk, WebKit, Gio, GLib

APP_ID = "io.github.agentic.Agentic"
HTML_PATH = "/app/share/agentic/index.html"


class AgenticWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="Agentic")
        self.set_default_size(1200, 800)

        self.webview = WebKit.WebView()
        settings = self.webview.get_settings()
        settings.set_enable_developer_extras(True)
        settings.set_javascript_can_access_clipboard(True)

        uri = GLib.filename_to_uri(HTML_PATH, None)
        self.webview.load_uri(uri)

        self.set_child(self.webview)


class AgenticApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                          flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        win = self.props.active_window
        if not win:
            win = AgenticWindow(self)
        win.present()


if __name__ == "__main__":
    app = AgenticApp()
    sys.exit(app.run(sys.argv))
