#!/usr/bin/env bash
# Build and install the Agentic Flatpak locally.
set -e

APP_ID="io.github.agentic.Agentic"
MANIFEST="${APP_ID}.yml"

echo "==> Ensuring runtimes are installed (Flathub remote required)"
flatpak remote-add --if-not-exists --user flathub https://flathub.org/repo/flathub.flatpakrepo
flatpak install --user -y flathub org.gnome.Platform//46 org.gnome.Sdk//46

echo "==> Building"
flatpak-builder --force-clean --user --install build-dir "$MANIFEST"

echo "==> Done. Run it with:"
echo "    flatpak run $APP_ID"
