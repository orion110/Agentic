# Agentic — Flatpak packaging

This turns `Agentic.html` into a native Linux desktop app using a small
GTK4 + WebKitGTK launcher, packaged as a Flatpak.

## Layout

```
agentic-flatpak/
├── io.github.agentic.Agentic.yml           # flatpak-builder manifest
├── io.github.agentic.Agentic.desktop       # app launcher entry
├── io.github.agentic.Agentic.metainfo.xml  # AppStream metadata
├── build.sh                                 # one-shot build/install script
├── icons/icon.png                           # app icon (extracted from the HTML favicon)
└── app/
    ├── index.html                           # your original file, unmodified
    └── main.py                              # GTK4/WebKit6 window that loads index.html
```

## Requirements (on your Linux machine, not in this sandbox)

- `flatpak` and `flatpak-builder` installed (e.g. `sudo apt install flatpak flatpak-builder`)
- Internet access to Flathub (this sandbox is network-restricted, so the
  actual build has to happen on your machine)

## Build & run

```bash
cd agentic-flatpak
chmod +x build.sh
./build.sh
flatpak run io.github.agentic.Agentic
```

`build.sh` adds the Flathub remote, pulls `org.gnome.Platform//46` +
`org.gnome.Sdk//46` (~500 MB–1 GB first time, cached after), builds the
app, and installs it for your user.

## Producing a distributable `.flatpak` bundle (single file)

```bash
flatpak build-bundle ~/.local/share/flatpak/repo agentic.flatpak io.github.agentic.Agentic
```

This gives you `agentic.flatpak`, which anyone can install with:

```bash
flatpak install agentic.flatpak
```

## Notes / things to adjust

- **App ID**: `io.github.agentic.Agentic` is a placeholder reverse-DNS ID.
  Rename it (in the `.yml`, `.desktop`, `.metainfo.xml` filenames and
  contents, and in `main.py`'s `APP_ID`) to match a domain/namespace you
  actually control if you plan to publish this.
- **Offline app**: `index.html` is bundled read-only inside the sandbox at
  `/app/share/agentic/index.html`. If the app needs network access (e.g. it
  calls external APIs), add `--share=network` to `finish-args` in the
  manifest.
- **Runtime version**: pinned to GNOME 46, matching the WebKit 6.0 GTK4
  bindings used in `main.py`. Bump both together if you target a newer
  GNOME runtime.
- If you'd rather ship this as a plain Electron-style app instead of a
  WebKitGTK wrapper, that's also possible, but Electron bundles are much
  larger and slower to flatpak-build than this WebKitGTK approach.
